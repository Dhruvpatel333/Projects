
public class Student extends UniPerson implements SSN {


	private double GPA;
	private int studentNumber;

	
	
	public double getGPA() {
		return GPA;
	}
	public void setGPA(double gPA) {
		GPA = gPA;
	}
	public int getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}

	public void uniAtendee() {
		System.out.println("I do attend the University");
		
	}
	
	public void whatIsSSN() {
		System.out.println("SSN is 102-31-2311");
		
	}

	
	
}
