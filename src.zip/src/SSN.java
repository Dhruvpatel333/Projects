
public interface SSN {

	public void whatIsSSN();
}
