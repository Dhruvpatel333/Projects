
public class TestHarn {

	public static void main(String[] args) {
		
		Faculty sansa = new Faculty();
		Teacher pablo = new Teacher();
		BuisStudent jamin = new BuisStudent();
		CompStudent tyrion = new CompStudent();
		
		
		//BuisStudent JAMIN
		
		jamin.setAge(21);
		jamin.setName("Jamin");
		System.out.println( jamin.getName() + " is "+ jamin.getAge());
		
		jamin.uniAtendee();
		jamin.whatIsSSN();
		jamin.setGPA(1.2);
		jamin.setStudentNumber(12343242);
		System.out.println(jamin.getName() +" student number is "+ jamin.getStudentNumber());
		System.out.println(jamin.getName() +" has a "+ jamin.getGPA() + " GPA");
		jamin.setEzClass("English");
		jamin.setHardClass("Calculus");
		System.out.println("Jamin's easiest class is "+ jamin.getEzClass());
		System.out.println("Jamin's hardest class is "+ jamin.getHardClass());
		
		System.out.println("\n");
		System.out.println("\n");

		//CompStudent TYRION
		

		tyrion.setAge(24);
		tyrion.setName("Tyrion");
		System.out.println( tyrion.getName() + " is "+ tyrion.getAge());
		
		tyrion.uniAtendee();
		tyrion.whatIsSSN();
		tyrion.setGPA(4.0);
		tyrion.setStudentNumber(825284248);
		System.out.println(tyrion.getName() +" student number is "+ tyrion.getStudentNumber());
		System.out.println(tyrion.getName() +" has a "+ tyrion.getGPA() + " GPA");
		tyrion.setEzClass("English");
		tyrion.setHardClass("Calculus");
		System.out.println("Tyrion's easiest class is "+ tyrion.getEzClass());
		System.out.println("Tyrion's hardest class is "+ tyrion.getHardClass());
	
		
		
		System.out.println("\n");
		System.out.println("\n");
		
		//Teacher PABLO
		
		
		pablo.setAge(40);
		pablo.setName("Pablo");
		System.out.println( pablo.getName() + " is "+ pablo.getAge());
		pablo.setStaffNum(31313123);
		System.out.println( pablo.getName() + " staff number is "+ pablo.getStaffNum());
		pablo.uniAtendee();
		pablo.whatIsSSN();
		pablo.setTitle("Teacher in Mystical Arts");
		
		System.out.println( pablo.getName() + " is an "+ pablo.getTitle());
		pablo.setSalary(30000);
		pablo.setWorkHoursPerWeek(40);
		System.out.println( pablo.getName() + " has an salary of "+ pablo.getSalary()+ " and works for " + pablo.getWorkHoursPerWeek() + 
				" hours a week.");
		
		//Faculty SANSA
		
		System.out.println("\n");
		System.out.println("\n");
		
				sansa.setAge(34);
				sansa.setName("Sansa");
				System.out.println( sansa.getName() + " is "+ sansa.getAge());
				sansa.setStaffNum(34255223);
				System.out.println( sansa.getName() + " staff number is "+ sansa.getStaffNum());
				sansa.uniAtendee();
				sansa.whatIsSSN();
				sansa.setTitle("Online IT help");
				
				System.out.println( sansa.getName() + " is an "+ sansa.getTitle());
				sansa.setSalary(80000);
				sansa.setWorkHoursWeekly(60);
				System.out.println( sansa.getName() + " has an salary of "+ sansa.getSalary()+ " and works for " + sansa.getWorkHoursWeekly() + 
						" hours a week.");

	}

}
