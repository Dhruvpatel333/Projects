
public class CompStudent extends Student {
	private String hardClass;
	private String ezClass;
	
	public String getHardClass() {
		return hardClass;
	}
	public void setHardClass(String hardClass) {
		this.hardClass = hardClass;
	}
	public String getEzClass() {
		return ezClass;
	}
	public void setEzClass(String ezClass) {
		this.ezClass = ezClass;
	}
	
	
}
