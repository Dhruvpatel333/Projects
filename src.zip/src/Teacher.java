
public class Teacher extends Staff {

	
	private double salary;
	private int workHoursPerWeek;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getWorkHoursPerWeek() {
		return workHoursPerWeek;
	}
	public void setWorkHoursPerWeek(int workHoursPerWeek) {
		this.workHoursPerWeek = workHoursPerWeek;
	}
	
	

}
