
public class Faculty extends Staff{

	
	private double salary;
	private double workHoursWeekly;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getWorkHoursWeekly() {
		return workHoursWeekly;
	}
	public void setWorkHoursWeekly(double workHoursWeekly) {
		this.workHoursWeekly = workHoursWeekly;
	}
	@Override
	public void whatIsSSN() {
		System.out.println("SSN is : 034-31-9421");
		
	}

}
