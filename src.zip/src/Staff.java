
public class Staff extends UniPerson implements SSN {
	


	private String title;
	private int staffNum;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getStaffNum() {
		return staffNum;
	}
	public void setStaffNum(int staffNum) {
		this.staffNum = staffNum;
	}
	
	public void whatIsSSN() {
		System.out.println("SSN is : 132-93-2331");
		
	}
	
	public void uniAtendee() {
		System.out.println("I do not attend the school, I provide my services");
		
	}
	
	
	
}
